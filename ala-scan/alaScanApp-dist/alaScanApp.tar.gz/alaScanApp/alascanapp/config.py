'''

Configuration module.

Created on 20 Jun 2017

@author: Amaurys Ávila Ibarra
'''
from .initialize import __dir_chi_opt, __dir_l_src_opt, __dir_l_blibs_opt, __dir_l_rslt_opt, __dir_l_chi_opt
from .initialize import __dir_cpp_opt, __dir_bude_opt, __dir_getsd_opt, __dir_colsd_opt, __dir_msrc_opt, __dir_mrslt_opt
from .initialize import __dir_wrk_opt, __dir_scan_opt, __dir_blibs_opt, __dir_rslt_opt, __dir_src_opt
from .initialize import __exe_bude_opt, __exe_colsd_opt, __exe_getsd_opt, __exe_fbude_opt, __exe_fcolsd_opt, __exe_fgetsd_opt
from .initialize import __names_b_bmc_opt, __names_b_ctrl_opt, __names_b_gen_zero_opt, __names_b_ff_opt, __names_b_transf_opt
from .initialize import __names_lig_sd_opt, __names_rcpt_sd_opt, __gen_max_auto_num_opt
from .initialize import __names_ligs_list_opt, __names_rcpts_list_opt, __names_rslt_lig_list_opt, __names_rslt_rcpt_list_opt
from .initialize import create_configuration, __general_sect, __exe_sect, __dir_sect, __names_sect, __config_file

cfg = create_configuration()

config_file = __config_file
exe_sect = __exe_sect
dir_sect = __dir_sect
names_sect = __names_sect
general_sect = __general_sect

angstrom_symb = u'\u212B'

# Indices from BUDE results in the order they appear blank space separated
# after splitting a line.
# Index Number Name Chain     InterDG    InterDDG  NormTerDDG     IntraDG    IntraDDG  NormTraDDG ChainAtoms     SD
#     1    340  ALA     B   -326.3490      0.0000      0.0000  -1264.1267      0.0000      0.0000          0     0.0000
#
# b_idx -- Index from BUDE, unique incremental integer.
# b_rNum_idx -- Index for the residue number.
# b_rNam_idx -- Index for the residue name.
# b_ch_idx -- Index for the chain ID.
# b_rddG_idx -- Index for the ddG value.
# b_sch_idx -- Index for the sidechain size.
# b_sd_idx -- Index for the standard deviation.

b_idx = 0
b_rNum_idx = 1
b_rNam_idx = 2
b_ch_idx = 3
b_rddG_idx = 5
b_sch_idx = 10
b_sd_idx = 11

# Indices for the tuples of the results we process.
r_rNum_idx = 0
r_rNam_idx = 1
r_ch_idx = 2
r_rddG_idx = 3
r_sch_idx = 4
r_sd_idx = 5

# Key for deltaG in dictionary
deltaG_key = 'dG'

# Re-packing suffix
rpck_suffix = "repacked"

# Replot directory
replot_dir = "replot"

# Directory for file that exceeds Max number constellations
extra_const_dir = "extra_const"

# If there is scwrl
there_is_scwrl = True

# Flag to output info to the standard output.
verbose = False
# Flag to show plots
showplots = True
# Time format for verbose output.
time_fmt = "%H:%M:%S"
# date format for verbose output
date_fmt = "%c"

gen_max_auto_num_opt = __gen_max_auto_num_opt
dir_wrk_opt = __dir_wrk_opt
dir_scan_opt = __dir_scan_opt
dir_blibs_opt = __dir_blibs_opt
dir_rslt_opt = __dir_rslt_opt
dir_src_opt = __dir_src_opt
dir_chi_opt = __dir_chi_opt
dir_l_src_opt = __dir_l_src_opt
dir_l_blibs_opt = __dir_l_blibs_opt
dir_l_rslt_opt = __dir_l_rslt_opt
dir_l_chi_opt = __dir_l_chi_opt
dir_cpp_opt = __dir_cpp_opt
dir_bude_opt = __dir_bude_opt
dir_getsd_opt = __dir_getsd_opt
dir_colsd_opt = __dir_colsd_opt
dir_msrc_opt = __dir_msrc_opt
dir_mrslt_opt = __dir_mrslt_opt
exe_bude_opt = __exe_bude_opt
exe_colsd_opt = __exe_colsd_opt
exe_getsd_opt = __exe_getsd_opt
exe_fbude_opt = __exe_fbude_opt
exe_fcolsd_opt = __exe_fcolsd_opt
exe_fgetsd_opt = __exe_fgetsd_opt
names_b_bmc_opt = __names_b_bmc_opt
names_b_ctrl_opt = __names_b_ctrl_opt
names_b_gen_zero_opt = __names_b_gen_zero_opt
names_b_ff_opt = __names_b_ff_opt
names_b_transf_opt = __names_b_transf_opt
names_ligs_list_opt = __names_ligs_list_opt
names_rcpts_list_opt = __names_rcpts_list_opt
names_rslt_lig_list_opt = __names_rslt_lig_list_opt
names_rslt_rcpt_list_opt = __names_rslt_rcpt_list_opt
names_lig_sd_opt = __names_lig_sd_opt
names_rcpt_sd_opt = __names_rcpt_sd_opt

