'''
Created on 5 Jul 2017

@author: Amaurys Ávila Ibarra
'''
from os import path, makedirs


def create_my_file(name, content):
    '''
    Create file with name and writes its content from a list of strings
    either terminate by new line or not.
    
    Or the content is a single string.
    '''
    out_file = open(name, 'w')

    if isinstance(content, list):
        for line in content:
            if isinstance(line, str) and line.endswith('\n'):
                out_file.write("%s" % (line))
            else:
                out_file.write("%s\n" % (line))
    else:
        out_file.write("%s\n" % (content))

    out_file.close()


def create_nested_dir(nested_dir):
    '''
    Create nested directories if they do not exist.
    '''

    if not path.exists(nested_dir):
        makedirs(nested_dir)


def read_file(filename):
    '''
    Read a file a return a list of lines.
    '''
    f_content = []
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            f_content.append(line)
    return f_content

