'''
Created on 14 Jun 2017

@author: Amaurys Ávila Ibarra
'''

from ntpath import basename
import subprocess, sys

from isambard import ampal


def print_std_error(my_msg):
    print(my_msg, file=sys.stderr)


def run_command(executable, command):
    '''
    Run a command within a shell and pipes standard output and error.
    If return code is not 0 breaks. Otherwise returns the a CompletedProcess object.
    Arguments.
    executable -- The name of the executable that was used in the command.
                  Used only for creating messages.
    command -- Full command as it would have been given in the shell command line.
    
    '''

    executable = basename(executable)

    proc = subprocess.run([command], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

    if proc.returncode > 0:
        print("Fatal Error: %s could not run properly. It returns code (%i)" % (executable, proc.returncode), file=sys.stderr)
        if proc.stderr:
            print("%s error message:\n%s\n" % (executable, proc.stderr), file=sys.stderr)
        sys.exit(3)

    return proc


def is_multi_model(my_ampal):
    '''
    Check that we have an Ampal Container (multiple models PDB), if so 
    return true, otherwise return false.
    '''
    if isinstance(my_ampal, ampal.assembly.AmpalContainer):
        return True
    else:
        return False


def upper_my_list(a_list):
    '''
    Upper-casing all elements of list of strings.
    '''
    return [e.upper() for e in a_list]


def get_legal_chains(my_ampal):
    '''
    Get all chain IDs from the ampal object
    
    my_ampal -- It could be an Ampal Container or a polymer
    '''

    legal_chains = []

    if is_multi_model(my_ampal):
        model = my_ampal[0]
    else:
        model = my_ampal

    for chain in model:
        legal_chains.append(chain.id.upper())

    return legal_chains

