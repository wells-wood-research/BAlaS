'''

Repack all chains for the ampal object accordingly.

Created on 30 Jun 2017

@author: Amaurys Ávila Ibarra
'''
from copy import deepcopy


def repackAmpal(my_ampal, is_multimodel):

    rpck_ma = deepcopy(my_ampal)

    if  is_multimodel:
        for m_idx in range (0, len(rpck_ma)):
            rpck_ma[m_idx].repack_all()
    else:
        rpck_ma.repack_all()
    return rpck_ma
